<?php session_start();
 $receipts=  $this->db->query("select* from eduportal_fees_payment_log where student_id='".$this->session->userdata('student_id')."' and payment_fee_type='2'");
 foreach($my_data as $row1){
$school = $this->db->get_where('schools', array("schoolid" => $my_data->school))->row();
$dept = $this->db->get_where('department', array("deptID" => $my_data->dept))->row();
$programme = $this->db->get_where('student_type', array("student_type_id" => $my_data->programme))->row();
$programme_type = $this->db->get_where('programme_type', array("programme_type_id" => $my_data->prog_type))->row();
$yr = $this->db->get_where('course_year_of_study', array("year_of_study_id" => $row1['level']))->row();
//$stype=$row1['programme'];
//$levels = $this->db->query("select *  from course_year_of_study where student_type_id='$stype'");
 }
 $stu_prog=$my_data->prog_type;
?>

<p style="font-size:13px; color:#9d0000;"><?php if(isset($_SESSION['err_msg'])){echo $_SESSION['err_msg'];} ?></p>
<div class="row">

	<div class="col-md-12">



    	<!--CONTROL TABS START-->

		<ul class="nav nav-tabs bordered">

	

          	<!--li>
        		<a href="#add" data-toggle="tab"><i class="entypo-credit-card"></i>
            	<?php echo get_phrase('school_Fee_payment_form');?>
             	</a>
            </li-->
            <li class="active">
		        <a href="#pid" data-toggle="tab"><i class="entypo-credit-card"></i>
	            <?php echo 'Fee Confirmation Form';?>
                </a>
            </li>
            
            		<li>
            	<a href="#list" data-toggle="tab"><i class="entypo-menu"></i>
					<?php echo get_phrase('Fee_Payment_History');?>
                </a>
            </li>



		</ul>

    	<!--CONTROL TABS END-->
	<div class="widget stacked widget-table">
				<div class="widget-content">
					<div class="tab-content">

				<!--TABLE LISTING STARTS-->

				<div class="tab-pane box " id="list">



					<table  class="table table-bordered datatable" id="table_export">
						<thead>
							<tr>
							<th><div>S/N</div></th>
							<th><div>Portal ID</div></th>
							<th><div>Semester</div></th>
							<th><div>Level</div></th>
							<th><div>Amount (₦)</div></th>
							<th><div>Session</div></th>
							<th><div>Payment Code</div></th>
							<th><div>Date</div></th>
                            <th><div>Action</div></th>
							</tr>
						</thead>
						<tbody><?php $i =1; ?>
							<?php foreach($receipts->result() as $row){?>
							<tr>
								<td><?php echo $i;?></td>
								<td><?php echo $row->regno;?></td>
								<td><?php echo $row->semester;?></td>
								<td><?php echo $row->payment_level;?></td>
								<td>₦ <?php echo $row->payment_amount;?></td>
								<td><?php echo $row->payment_session;?></td>
								<td><?php echo $row->payment_code;?></td>
								<td><?php echo $row->payment_date;?></td>
								<td> 
								<a target ="_blank" href="<?php echo base_url();?>index.php?student/receiptprintout/<?php echo $row->payment_code;?>">
									<button type="submit" class="btn btn-info"><i class="entypo-credit"></i> View Receipt</button>
								</a>
								</td>
							</tr><?php $i++;?>
							<?php }?>
						</tbody>
					</table>

				</div>

				<!--TABLE LISTING ENDS-->



                <div class="tab-pane box active" id="pid" style="padding: 5px">
                
                	<div style="padding: 15px; paddidng-left: 30px">
					<p style="font-size:13px; color:#9d0000;"><?php if(isset($_SESSION['payeeError'])){echo $_SESSION['payeeError']; $_SESSION['payeeError']='';} ?></p>
					</div>
					<div class="box-content">

						<?php if($stu_prog==4 || $stu_prog==1){ echo form_open('student/processRemitaFeePayment', array('class' => 'form-horizontal form-groups-bordered validate','target'=>'_top')); }else {echo form_open('student/processEtranzactFeePayment', array('class' => 'form-horizontal form-groups-bordered validate','target'=>'_top'));} ?> <input type="hidden" name="portalID" value="<?php echo $my_data->portal_id;?>" />

						<!--div class="form-group">

							

							<div class="col-sm-5">

						
							</div>

						</div-->

                        

                       
	
            	<div class="form-group">
				<label class="col-sm-3 control-label" for="course name"><?php if($stu_prog==1 || $stu_prog==4 ){?>RRR<?php } else {?>Confirmation Code<?php }?></label>
				<div class="col-sm-5">
					
				<input type="text"  name="confirmcode" class="form-control eduportal-input" required="required" />
				</div>
			</div>
            
                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-5">
                                <button type="submit" class="btn btn-info"><?php echo get_phrase('Confirm Fee Payment');?></button>
                            </div>
                        </div>

                        </form>

           		  </div>
                </div>
                	
						<!--button type="button" class="btn btn-info"><i class="entypo-credit"></i> Reprint Bank Printout</button-->
						
					</a>
					</div>
                	

                
                	<div style="padding: 15px; paddidng-left: 30px">
                	</div>
                	

            </div>



            





		
		</div>
		</div>

	</div>

</div>



