<!-- Footer -->
<footer class="main">
	<p>&copy;<?php echo Date('Y'); ?> 
		<strong><?php echo $system_name;?></strong>. 
		Powered By 
		<a href="http://www.gtcocalscan.com" target="_blank"> &nbsp; GTCO Calscan Nig Ltd</a>
	</p>
</footer>
