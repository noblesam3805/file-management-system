<?php if($account_type == 'student' ){ ?>
<script type="text/javascript">
$(document).ready(function(){
	
	var hostel_a = $('#d-hostel_a');
	var hostel_b = $('#d-hostel_b');
	var hostel_c = $('#d-hostel_c');
	
	var hostel_d1 = $('#d-hostel_d1');
	var hostel_d2 = $('#d-hostel_d2');
	var hostel_d3 = $('#d-hostel_d3');
	var hostel_d4 = $('#d-hostel_d4');
	
	var hostel_e1 = $('#d-hostel_e1');
	var hostel_e2 = $('#d-hostel_e2');
	var hostel_e3 = $('#d-hostel_e3');
	var hostel_e4 = $('#d-hostel_e4');
	
	var hostel_f1 = $('#d-hostel_f1');
	var hostel_f2 = $('#d-hostel_f2');
	var hostel_f3 = $('#d-hostel_f3');
	var hostel_f4 = $('#d-hostel_f4');
	
	
	var hostel_h = $('#d-hostel_h');
	var hostel_i = $('#d-hostel_i');
	
	var hostel_g1 = $('#d-hostel_g1');
	var hostel_g2 = $('#d-hostel_g2');
	var hostel_g3 = $('#d-hostel_g3');
	var hostel_g4 = $('#d-hostel_g4');
	
	$('#hostel_g1').click(function(){
		
		hostel_a.hide();
		hostel_b.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_g1').slideToggle(600);
	});
	
	$('#hostel_a').click(function(){
		
		hostel_b.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_a').slideToggle(600);
	});
	
	$('#hostel_b').click(function(){
		
		hostel_a.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_b').slideToggle(600);
	});
	
	$('#hostel_c').click(function(){
		
		hostel_a.hide();
		hostel_b.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_c').slideToggle(600);
	});
	
	$('#hostel_d4').click(function(){
		
		hostel_a.hide();
		hostel_b.hide();
		hostel_c.hide();
	
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
	
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_d4').slideToggle(600);
	});
	
	$('#hostel_d1').click(function(){
		
		hostel_a.hide();
		hostel_b.hide();
		hostel_c.hide();
		
		
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
		
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_d1').slideToggle(600);
	});
	
	$('#hostel_d2').click(function(){
		
		hostel_a.hide();
		hostel_b.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d3.hide();
		hostel_d4.hide();
		
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_d2').slideToggle(600);
	});
	
	$('#hostel_d3').click(function(){
		
		hostel_a.hide();
		hostel_b.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d4.hide();
		
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_d3').slideToggle(600);
	});
	
	$('#hostel_e1').click(function(){
		
		hostel_a.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
	
		hostel_b.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_e1').slideToggle(600);
	});
	
	$('#hostel_e2').click(function(){
		
		hostel_a.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		hostel_e1.hide();
		hostel_e3.hide();
		hostel_e4.hide();
	
		hostel_b.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_e2').slideToggle(600);
	});
	
	$('#hostel_e3').click(function(){
		
		hostel_a.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e4.hide();
	
		hostel_b.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_e3').slideToggle(600);
	});
	
	$('#hostel_e4').click(function(){
		
		hostel_a.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
	
		hostel_b.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_e4').slideToggle(600);
	});
	
	$('#hostel_f1').click(function(){
		
		hostel_a.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		hostel_b.hide();
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_f1').slideToggle(600);
	});
	
	$('#hostel_f2').click(function(){
		
		hostel_a.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		hostel_f1.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		hostel_b.hide();
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_f2').slideToggle(600);
	});
	
	$('#hostel_f3').click(function(){
		
		hostel_a.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f4.hide();
		
		hostel_b.hide();
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_f3').slideToggle(600);
	});
	
	$('#hostel_f4').click(function(){
		
		hostel_a.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		
		hostel_b.hide();
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_f4').slideToggle(600);
	});
	
	$('#hostel_h').click(function(){
		
		hostel_a.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		hostel_b.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_h').slideToggle(600);
	});
	
	$('#hostel_i').click(function(){
		
		hostel_a.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		hostel_h.hide();
		hostel_b.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_i').slideToggle(600);
	});
	
	$('#hostel_g2').click(function(){
		
		hostel_a.hide();
		hostel_b.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g3.hide();
		hostel_g4.hide();
		$('#d-hostel_g2').slideToggle(600);
	});
	
	$('#hostel_g3').click(function(){
		
		hostel_a.hide();
		hostel_b.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g4.hide();
		$('#d-hostel_g3').slideToggle(600);
	});
	
	$('#hostel_g4').click(function(){
		
		hostel_a.hide();
		hostel_b.hide();
		hostel_c.hide();
		
		hostel_d1.hide();
		hostel_d2.hide();
		hostel_d3.hide();
		hostel_d4.hide();
	
		hostel_e1.hide();
		hostel_e2.hide();
		hostel_e3.hide();
		hostel_e4.hide();
		
		hostel_f1.hide();
		hostel_f2.hide();
		hostel_f3.hide();
		hostel_f4.hide();
		
		
		hostel_h.hide();
		hostel_i.hide();
		
		hostel_g1.hide();
		hostel_g2.hide();
		hostel_g3.hide();
		$('#d-hostel_g4').slideToggle(600);
	});
});
</script>
 
<?php } ?>   
    
    

	<link rel="stylesheet" href="assets/js/datatables/responsive/css/datatables.responsive.css">
	<link rel="stylesheet" href="assets/js/select2/select2-bootstrap.css">
	<link rel="stylesheet" href="assets/js/select2/select2.css">

   	<!-- Bottom Scripts -->
   	<script src="assets/js/angular.min.js"></script>
	<script src="assets/js/ui-bootstrap-tpls-0.10.0.min.js"></script>
	<script src="assets/js/app/app.js"></script>
	<script src="assets/js/gsap/main-gsap.js"></script>
	<script src="assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js"></script>
	<script src="assets/js/bootstrap.js"></script>
	<script src="assets/js/joinable.js"></script>
	<script src="assets/js/resizeable.js"></script>
	<script src="assets/js/neon-api.js"></script>
    <script src="assets/js/jquery.validate.min.js"></script>
	<script src="assets/js/fullcalendar/fullcalendar.min.js"></script>
    <script src="assets/js/bootstrap-datepicker.js"></script>
    <script src="assets/js/fileinput.js"></script>
    
    
    <script src="assets/js/jquery.dataTables.min.js"></script>
	<script src="assets/js/datatables/TableTools.min.js"></script>
	<script src="assets/js/dataTables.bootstrap.js"></script>
	<script src="assets/js/datatables/jquery.dataTables.columnFilter.js"></script>
	<script src="assets/js/datatables/lodash.min.js"></script>
	<script src="assets/js/datatables/responsive/js/datatables.responsive.js"></script>
    <script src="assets/js/select2/select2.min.js"></script>
    
	<script src="assets/js/neon-calendar.js"></script>
	<script src="assets/js/neon-chat.js"></script>
	<script src="assets/js/neon-custom.js"></script>
	<script src="assets/js/neon-demo.js"></script>

    
<script type="text/Javascript">	
	$(document).ready(function(){

		var controller = 'sadmin';
		var base_url = '<?php echo base_url() . 'index.php'; ?>';
		
		function showEditForm(a){
			$.ajax({
			type:"post",
			url:base_url + '?' + controller + '/do_ajax/edit/' + a,
			data:{'type' : 'value'},
			success:function(data){
				$("html, body").animate({ scrollTop: 0 }, "slow");
				$("#editResult").html(data);
				document.getElementById('result').innerHTML = '';
				
				//$("#search").val("");
			 }
		  });
		}
	});
</script>




<!-----  DATA TABLE EXPORT CONFIGURATIONS ----->                      
<script type="text/javascript">

	jQuery(document).ready(function($)
	{
		

		var datatable = $("#table_export").dataTable();
		
		$(".dataTables_wrapper select").select2({
			minimumResultsForSearch: -1
		});
	});
		
</script>