<p style="font-size:13px; color:#9d0000;">&nbsp;</p>
<div class="row">

	<div class="col-md-12">



    	<!------CONTROL TABS START------->

		<ul class="nav nav-tabs bordered">

			<li  class="active">

            	<a href="#manage" data-toggle="tab"><i class="entypo-menu"></i>

					<?php echo "Manage Courses";?>

           	  </a></li>

          <li >



		</ul>

    	<!--CONTROL TABS END-->
		<div class="widget stacked widget-table">
			<div class="widget-content">
				<div class="tab-content">
					<div class="tab-pane box active" id="manage" style="padding: 5px">
							<div class="box-content">
						
							<ul class="list-group">
							 <div id="table-content">
			
			<h3>Upload Courses !</h3>
			<hr />
			<p>&nbsp;</p>
			<div style="margin-left:30px">
			  <p>Note Supported format **CSV </p>
			  <p>&nbsp;</p>
			  <p><span style="font-size:13px; color:#9d0000;">
			    <?php if(isset($_SESSION["error"])){ echo $_SESSION["error"];}?>
			  </span> 
			    <div style="width:600px; height:100%" align="center">
                  <form id="imageform" name="imageform" method="post" enctype="multipart/form-data" action='index.php?sadmin/ajax_upload_courses' >
                      <p>
                        <input type="file" id="photoimg" name="photoimg" style="width: 228px" class="" />
                      </p>
                      <p>
                        <input type="submit" name="submit" id="submit" value="Upload">
                      </p>
                  </form>
                  
                </div>
				<div id='preview'>
                 <form  method="post" action=""  onsubmit="javascript: return false;" >
                <table width="843"  class="" >
      <thead>
        <tr bgcolor="#FFFFFF">
          <th width="61"><div align="left" ><span  style="color:#000">ID</span></div></th>
          <th width="197"><div align="left" class="style6"><span class="style4" style="color:#000">COURSE CODE</span></div></th>
          <th width="281"><div align="left" class="style6"><span class="style4" style="color:#000">COURSE TITLE </span></div></th>
          <th width="113"><div align="center" class="style6"><span class="style4" style="color:#000">ACTIVATED</span></div></th>
		  <th width="157" align="center"><div align="center" class="style6"><span class="style4" style="color:#000">ACTION</span></div></th>
 
        
        </tr>
      </thead>
    
	  <?php 
	  $id=1;
	// $query =mysql_query("select* from eduportal_courses_temp where sid = '$_SESSION[sid]'") or die("1");
	 $query =mysql_query("select* from eduportal_courses order by course_code") or die("1");
								while(list($id1,$coursecode,$ct,$code,$activated) = mysql_fetch_array($query))
								{?>
         <tbody> 
           <tr bgcolor="#E2E2E2">
             <td>&nbsp;</td>
             <td>&nbsp;</td>
             <td>&nbsp;</td>
             <td>&nbsp;</td>
             <td>&nbsp;</td>
             
           </tr>
           <tr>
          <td><div align="left"><span class="style5"><?php echo $id;?></span></div></td>
          <td><div align="left"><span class="style5"><?php echo $coursecode; ?></span></div></td>
         
          <td><div align="left"><span class="style5" id="courseHint<?php echo $id1;?>"><?php echo $ct  ;?></span><span class="style5" id="courseinput<?php echo $id1;?>" style="display:none;"><input name="coursename<?php echo $id1;?>" class="comme" id="coursename<?php echo $id1;?>" value="<?php echo $ct  ;?>" size="50" onkeydown="checkCommentBoxInputKey(event,this.value,<?php echo $id1;?>);"/></span><span id="commload<?php echo $id1;?>"></span></div></td>
		 
          <td><div align="center"><span class="style5">
            <?php if($activated=="1"){echo "TRUE";} else { echo "FALSE";};?>
          </span></div></td>
          <td align="center"><a href="#" onclick="OpenEditCourse(<?php echo $id1;?>)">Edit Details</a></td>
        </tr></tbody>
				  <?php 
				  $id = $id +1;}?>
</table></form></div>&nbsp;</p>
			  <p>&nbsp;</p>
			</div>
			</div>
							</ul>						
		                </div>
		            </div>
				</div>
			</div>
		</div>

	</div>

</div>

<?php if(isset($_SESSION["error"])){ unset($_SESSION["error"]);}?>

