<div class="sidebar-menu">
		<header class="logo-env" >
			
            <!-- logo -->
			<div class="logo" style="">
				<a href="<?php echo base_url();?>">
				<img src="assets/images/eduportal.png"  style="max-height:60px;"/>
				</a>
				<div style="text-align:center; margin-top:15px;">
					<a href="">
						<img src="assets/images/default.png" style="border-radius:100px; width:80px; height:80px;" />
					</a>
				</div>
			</div>
            
			<!-- logo collapse icon -->
			<div class="sidebar-collapse" style="">
				<a href="#" class="sidebar-collapse-icon with-animation">

					<i class="entypo-menu"></i>
				</a>
			</div>

			<!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
			<div class="sidebar-mobile-menu visible-xs">
				<a href="#" class="with-animation">
					<i class="entypo-menu"></i>
				</a>
			</div>
		</header>

		<div style="border-top:1px solid rgba(69, 74, 84, 0.7);"></div>
		<ul id="main-menu" class="">
			<!-- add class "multiple-expanded" to allow multiple submenus to open -->
			<!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->

			
			
			
           <!-- DASHBOARD -->
           <li class="<?php if($page_name == 'dashboard')echo 'active';?> ">
				<a href="<?php echo base_url();?>index.php?sadmin/dashboard">
					<i class="entypo-gauge"></i>
					<span><?php echo get_phrase('dashboard');?></span>
				</a>
           </li>
           <?php if($this->session->userdata('level') == '3' || $this->session->userdata('level') == '1' || $this->session->userdata('level') == '2'){?>
           <li class="">
				<a target="_blank" href="<?php echo base_url();?>index.php?sadmin/student_portal">
					<i class="entypo-doc-text-inv"></i>
					<span><?php echo get_phrase('_student_portal');?></span>
				</a>
			</li>
			<?php } ?>
            
            <!-- ADMISSIONS -->
           <?php if($this->session->userdata('level') == '3' || $this->session->userdata('level') == '1' || $this->session->userdata('level') == '2' || $this->session->userdata('level') == '4'){?>
		   <!-- TEACHER -->
           <li class="<?php if($page_name == 'upload_adm_list' ||
           						   $page_name == 'view_adm_list')
												echo 'opened active has-sub';?> ">
				<a href="#">
					<i class="entypo-graduation-cap"></i>
					<span><?php echo get_phrase('Admissions');?></span>
				</a>
				<ul>

                	
					<li class="<?php if($page_name == 'upload_adm_list')echo 'active';?> ">
    				    <a href="<?php echo base_url();?>index.php?sadmin/upload_adm_list">
    				    	<span><i class="entypo-dot"></i><?php echo get_phrase('upload admission list');?></span>
    				    </a>
                    </li>
					<li class="<?php if($page_name == 'view_adm_list')echo 'active';?> ">
    				   <a href="<?php echo base_url();?>index.php?sadmin/view_adm_list">
    				    	<span><i class="entypo-dot"></i><?php echo get_phrase('view admission list');?></span>
    				    </a>
                    </li>

                 

				</ul>
			</li>
            <?php }?>

			<!-- STUDENT -->			
			<li class="<?php if($page_name == 'student_add' ||
				$page_name == 'student_bulk_add' ||
					$page_name == 'student_information' ||
					  $page_name == 'student_report' ||
					  $page_name == 'student_data' ||
					  $page_name == 'student_report_prog' ||
					  $page_name == 'login_details' ||
					  $page_name == 'nce_students' ||
					  $page_name == 'update_record' ||
					  $page_name == 'export_student' ||
					   $page_name == 'degree_students' ||
					   $page_name == 'student_report_sex' ||
						$page_name == 'student_marksheet')
							echo 'opened active has-sub';?> ">
				<a href="#">
					<i class="fa fa-group"></i>
					<span>&nbsp; <?php echo get_phrase('student Report');?></span>
				</a>
				<ul>
                	<!-- STUDENT ADMISSION >
					<li class="<?php if($page_name == 'student_add')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/student_add">
							<span><i class="entypo-dot"></i> <?php echo get_phrase('admit_student');?></span>
						</a>
					</li-->

                	<!-- STUDENT BULK ADMISSION -->
					

                    <li class="<?php if($page_name == 'student_report')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/student_report">
							<span><i class="entypo-dot"></i> <?php echo get_phrase('Student_Report');?></span>
						</a>
					</li>
					<?php if($this->session->userdata('hostel_allocation') != 1){ ?>
					<li class="<?php if($page_name == 'export_student')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/export_student">
							<span><i class="entypo-dot"></i> <?php echo get_phrase('Export Student Data');?></span>
						</a>
					</li>
					<?php } ?>

                    <li class="<?php if($page_name == 'student_data')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/student_data">
							<span><i class="entypo-dot"></i> <?php echo get_phrase('Student_Data');?></span>
						</a>
					</li>

                    <li class="<?php if($page_name == 'nce_students')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/nce_students">
							<span><i class="entypo-dot"></i> <?php echo get_phrase('NCE_Students');?></span>
						</a>
					</li>

                    <li class="<?php if($page_name == 'degree_students')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/degree_students">
							<span><i class="entypo-dot"></i> <?php echo get_phrase('Degree_Students');?></span>
						</a>
					</li>
					<?php if($this->session->userdata('level') == '3' || $this->session->userdata('level') == '1' || $this->session->userdata('level') == '2'){?>
                    <li class="<?php if($page_name == 'pre_nce')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/login_details">
							<span><i class="entypo-dot"></i> <?php echo get_phrase('Student_login_details');?></span>
						</a>
					</li>
					<?php } ?>

                    <li class="<?php if($page_name == 'student_report_sex')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/student_report_sex">
							<span><i class="entypo-dot"></i> <?php echo get_phrase('Student_Report_Sex');?></span>
						</a>
					</li>
					<?php if($this->session->userdata('level') == '3' || $this->session->userdata('level') == '1' || $this->session->userdata('level') == '2'){?>
					<!--li class="<?php if($page_name == 'update_record')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/update_record">
							<span><i class="entypo-dot"></i> <?php echo get_phrase('Update_Student_record');?></span>
						</a>
					</li-->
					<?php } ?>

				</ul>
			</li>
            
           <!-- TEACHER -->
           <?php if($this->session->userdata('level') == '3' || $this->session->userdata('level') == '1' || $this->session->userdata('level') == '2' || $this->session->userdata('level') == '4'){?>
		   <!-- TEACHER -->
           <li class="<?php if($page_name == 'academic' ||
           						   $page_name == 'non_academic' ||
           						     $page_name == 'teacher' ||
           						       $page_name == 'degree_staff' ||
									     $page_name == 'nce_staff')
												echo 'opened active has-sub';?> ">
				<a href="#">
					<i class="entypo-flag"></i>
					<span><?php echo get_phrase('Staff');?></span>
				</a>
				<ul>

                	
					<li class="<?php if($page_name == 'teacher')echo 'active';?> ">
    				    <a href="<?php echo base_url();?>index.php?sadmin/staff">
    				    	<span><i class="entypo-dot"></i><?php echo get_phrase('All Staff');?></span>
    				    </a>
                    </li>
					<li class="<?php if($page_name == 'academic')echo 'active';?> ">
    				    <a href="#">
    				    	<span><i class="entypo-dot"></i><?php echo get_phrase('Academic Staff');?></span>
    				    </a>
                    </li>

                    <li class="<?php if($page_name == 'non_academic')echo 'active';?> ">
    				    <a href="#">
    				    	<span><i class="entypo-dot"></i><?php echo get_phrase('Non-Academic Staff');?></span>
    				    </a>
                    </li>

                    <li class="<?php if($page_name == 'nce_staff')echo 'active';?> ">
    				    <a href="#">
    				    	<span><i class="entypo-dot"></i><?php echo get_phrase('NCE Staff');?></span>
    				    </a>
                    </li>

                    <li class="<?php if($page_name == 'degree_staff')echo 'active';?> ">
						<a href="#">
							<span><i class="entypo-dot"></i> <?php echo get_phrase('Degree Staff');?></span>
						</a>
					</li>

				</ul>
			</li>

           <!-- USERS -->
           <!--li class="<?php if($page_name == 'users' )echo 'active';?> ">
				<a href="<?php echo base_url();?>index.php?sadmin/users">
					<i class="entypo-user"></i>
					<span><?php echo get_phrase('Users');?></span>
				</a>
           </li-->
           <?php } ?>
		   
		   <!-- Academics -->
		   <?php //if($this->session->userdata('level') == '3' || $this->session->userdata('level') == '1' || $this->session->userdata('level') == '2'){?>
		   
		   <?php if($this->session->userdata('hostel_allocation') != 1){ ?>
			<li class="<?php if($page_name == 'grading_system' ||
           						   $page_name == 'student_reg' ||
           						   $page_name == 'add_grade' ||
									$page_name == 'credit_load' ||
									$page_name == 'courses')
												echo 'opened active has-sub';?> ">
				<a href="#">
					<i class="entypo-graduation-cap"></i>
					<span><?php echo get_phrase('Academics');?></span>
				</a>
				<ul>

                	<!-- Grading System -->
                	<?php if($this->session->userdata('level') == '3' || $this->session->userdata('level') == '1' || $this->session->userdata('level') == '2'){?>
					<li class="<?php if($page_name == 'grading_system')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/grading">
							<span><i class="entypo-dot"></i><?php echo get_phrase('_view_grades');?></span>
						</a>
					</li>
                    <li class="<?php if($page_name == 'add_grade')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/gradeOptions/add">
							<span><i class="entypo-dot"></i><?php echo get_phrase('_add_grade');?></span>
						</a>
					</li>
					<li class="<?php if($page_name == 'credit_load')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/credit_load">
							<span><i class="entypo-dot"></i><?php echo get_phrase('_credit_load');?></span>
						</a>
					</li>
					<li class="<?php if($page_name == 'student_reg')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/student_reg">
							<span><i class="entypo-dot"></i> <?php echo get_phrase('Student Reg');?></span>
						</a>
					</li>
					<?php } ?>
					<li class="<?php if($page_name == 'courses')echo 'active';?> ">
						<a target="_blank" href="<?php echo base_url();?>index.php?sadmin/course_management">
							<i class="entypo-dot"></i>
							<span><?php echo get_phrase('_course_management');?></span>
						</a>
				   </li>
                    

				</ul>
			</li>
		   <?php } ?>
		   
			<!-- PUTME -->
			<?php if($this->session->userdata('level') == '3'){ ?>
		   <li class="<?php if($page_name == 'putme_registration_details' ||
           						   $page_name == 'putme_student_details' ||
								   $page_name == 'putme_student_album')
								echo 'opened active has-sub';?> ">
				<a href="#">
					<i class="entypo-bell"></i>
					<span><?php echo get_phrase('Post Utme');?></span>
				</a>
				<ul>
					<li class="">
						<a href="">
							<span><i class="entypo-dot"></i><?php echo get_phrase('Start Registration');?></span>
						</a>
					</li>
                    <li class="<?php if($page_name == 'putme_registration_details')echo 'active';?> ">
						<a href="<?php echo base_url() . 'index.php?sadmin/putme_registration_details'; ?>">
							<span><i class="entypo-dot"></i><?php echo get_phrase('Registration Details');?></span>
						</a>
					</li>
					<li class="<?php if($page_name == 'putme_student_details')echo 'active';?> ">
						<a href="<?php echo base_url() . 'index.php?sadmin/putme_student_details' ?>">
							<span><i class="entypo-dot"></i><?php echo get_phrase('Student Details');?></span>
						</a>
					</li>
					<li class="<?php if($page_name == 'putme_student_album')echo 'active';?> ">
						<a href="<?php echo base_url() . 'index.php?sadmin/putme_student_album' ?>">
							<span><i class="entypo-dot"></i><?php echo get_phrase('Student Album');?></span>
						</a>
					</li>
				</ul>
			</li>
			<?php } ?>
		   

			<!-- Manage Fees-->
			<?php if($this->session->userdata('level') == '3' || $this->session->userdata('level') == '1' || $this->session->userdata('level') == '2'){?>
		   <li class="<?php if($page_name == 'etz_bulk_add' ||
           						   $page_name == 'add_manual' ||
									$page_name == 'manual_fee')
												echo 'opened active has-sub';?> ">
				<a href="#">
					&nbsp; <i class="fa fa-usd"></i>
					<span>&nbsp;<?php echo get_phrase(' Manage Fees');?></span>
				</a>
				<ul>

                	<!-- Live Etranzact -->
					<!--li class="<?php if($page_name == 'etz_bulk_add')echo 'active';?> ">
    				    <a href="<?php echo base_url();?>index.php?sadmin/etz_bulk_add">
    				    	<span><i class="entypo-dot"></i><?php echo get_phrase('Add_etranzact_manually');?></span>
    				    </a>
                    </li-->
                      <li class="<?php if($page_name == 'update_manual_payment_session')echo 'active';?> ">
    				    <a href="<?php echo base_url();?>index.php?sadmin/update_manual_payment_session">
    				    	<span><i class="entypo-dot"></i><?php echo "Update Payment Session";?></span>
    				    </a>
                    </li>

                    <li class="<?php if($page_name == 'manual_fee')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/manual_fee">
							<span><i class="entypo-dot"></i> <?php echo get_phrase('Manual_fee_report');?></span>
						</a>
					</li>

				</ul>
			</li>
			<?php } ?>
            
            
            <!-- Course Registration -->
            		<?php if($this->session->userdata('level') == '3' || $this->session->userdata('level') == '1' || $this->session->userdata('level') == '2'){?>
		   <li class="<?php if($page_name == 'upload_courses' ||
           						   $page_name == 'edit_courses' ||
									$page_name == 'assign_course_to_dept' ||
									$page_name == 'assign_credit_load' ||
									$page_name == 'assign_course_to_lecturer' ||
									$page_name == 'approve_registered_courses' ||
									$page_name == 'courses_assignment_report')
												echo 'opened active has-sub';?> ">
				<a href="#">
					&nbsp; <i class="entypo-doc-text-inv"></i>
					<span>&nbsp;<?php echo get_phrase(' Manage Courses');?></span>
				</a>
				<ul>

                	<!-- Live Etranzact -->
					<li class="<?php if($page_name == 'upload_courses')echo 'active';?> ">
    				    <a href="<?php echo base_url();?>index.php?sadmin/upload_courses">
    				    	<span><i class="entypo-dot"></i><?php echo "Upload Courses";?></span>
    				    </a>
                    </li-->
                    
                    
                	
                    <li class="<?php if($page_name == 'assign_course_to_dept')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/assign_course_to_dept">
							<span><i class="entypo-dot"></i> <?php echo "Assign Course To Dept.";?></span>
						</a>
					</li>
                    
                       <li class="<?php if($page_name == 'assign_credit_load')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/assign_credit_load">
							<span><i class="entypo-dot"></i> <?php echo "Assign  Credit Load";?></span>
						</a>
					</li>
                    
                     <li class="<?php if($page_name == 'assign_course_to_lecturer')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/assign_course_to_lecturer">
							<span><i class="entypo-dot"></i> <?php echo "Assign Course To Lecturer";?></span>
						</a>
					</li>
                    
                     <li class="<?php if($page_name == 'approve_registered_courses')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/approve_registered_courses">
							<span><i class="entypo-dot"></i> <?php echo "Approve Registered Courses";?></span>
						</a>
					</li>
					
					<li class="<?php if($page_name == 'courses_assignment_report')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/courses_assignment_report">
							<span><i class="entypo-dot"></i> <?php echo "Course Assignment Report";?></span>
						</a>
					</li>
                    
            

				</ul>
			</li>
			<?php } ?>
            
             <!-- Course Registration -->
            		<?php if($this->session->userdata('level') == '4' ){?>
		   <li class="<?php if(
           						  
									$page_name == 'assign_course_to_dept' ||
									$page_name == 'assign_credit_load' ||
								
									$page_name == 'approve_registered_courses')
												echo 'opened active has-sub';?> ">
				<a href="#">
					&nbsp; <i class="entypo-doc-text-inv"></i>
					<span>&nbsp;<?php echo get_phrase(' Manage Courses');?></span>
				</a>
				<ul>

        
                    
                    
                	
                    <li class="<?php if($page_name == 'assign_course_to_dept')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/assign_course_to_dept">
							<span><i class="entypo-dot"></i> <?php echo "Assign Course To Dept.";?></span>
						</a>
					</li>
                    
                       <li class="<?php if($page_name == 'assign_credit_load')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/assign_credit_load">
							<span><i class="entypo-dot"></i> <?php echo "Assign  Credit Load";?></span>
						</a>
					</li>
                    
                  
                    
                     <li class="<?php if($page_name == 'approve_registered_courses')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/approve_registered_courses">
							<span><i class="entypo-dot"></i> <?php echo "Approve Registered Courses";?></span>
						</a>
					</li>
                    
                 

				</ul>
			</li>
			<?php } ?>
            
            
              <!-- Course Registration -->
            		<?php if($this->session->userdata('level') == '3' || $this->session->userdata('level') == '1' || $this->session->userdata('level') == '2'){?>
		   <li class="<?php if($page_name == 'download_class_sheet' ||
           						   $page_name == 'download_score_sheet')
												echo 'opened active has-sub';?> ">
				<a href="#">
					&nbsp; <i class="entypo-doc-text-inv"></i>
					<span>&nbsp;<?php echo get_phrase(' Manage Results');?></span>
				</a>
				<ul>

                	               
                     <li class="<?php if($page_name == 'download_class_sheet')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/assign_course_to_lecturer">
							<span><i class="entypo-dot"></i> <?php echo "Download Class Sheet";?></span>
						</a>
					</li>
                    
                      <li class="<?php if($page_name == 'download_score_sheet')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/assign_course_to_lecturer">
							<span><i class="entypo-dot"></i> <?php echo "Download Marks/Score Sheet";?></span>
						</a>
					</li>
                    
                      <li class="<?php if($page_name == 'upload_score_sheet')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/assign_course_to_lecturer">
							<span><i class="entypo-dot"></i> <?php echo "Upload Result Sheet";?></span>
						</a>
					</li>

				</ul>
			</li>
			<?php } ?>
            

           <!-- Payment Report -->
           <?php if($this->session->userdata('level') == '3' || $this->session->userdata('level') == '1' || $this->session->userdata('level') == '2'){?>
		   <li class="<?php if($page_name == 'etranzact' ||
								$page_name == 'old_etranzact' ||
								  $page_name == 'export_etranzact' ||
								  $page_name == 'not_paid' ||
									$page_name == 'unmatched' ||
									  $page_name == 'payment_by_degree' ||
                                        $page_name == 'payment_by_nce')
												echo 'opened active has-sub';?> ">
				<a href="#">
					<i class="entypo-chart-bar"></i>
					<span><?php echo get_phrase('Payment Report');?></span>
				</a>
				<ul>

                	<!-- Live Etranzact -->
					<li class="<?php if($page_name == 'etranzact')echo 'active';?> ">
    				    <a href="<?php echo base_url();?>index.php?sadmin/etranzact">
    				    	<span><i class="entypo-dot"></i><?php echo get_phrase('Live_E-tranzact');?></span>
    				    </a>
                    </li>

                    <li class="<?php if($page_name == 'export_etranzact')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/export_etranzact">
							<span><i class="entypo-dot"></i> <?php echo get_phrase('Export Payment Data');?></span>
						</a>
					</li>

                    <li class="<?php if($page_name == 'old_etranzact')echo 'active';?> ">
    				    <a href="<?php echo base_url();?>index.php?sadmin/old_etranzact">
    				    	<span><i class="entypo-dot"></i><?php echo get_phrase('Old Fees');?></span>
    				    </a>
                    </li>

                    <li class="<?php if($page_name == 'not_paid')echo 'active';?> ">
    				    <a href="<?php echo base_url();?>index.php?sadmin/not_paid">
    				    	<span><i class="entypo-dot"></i><?php echo get_phrase('Student_not_paid');?></span>
    				    </a>
                    </li>

                    <li class="<?php if($page_name == 'unmatched')echo 'active';?> ">
    				    <a href="<?php echo base_url();?>index.php?sadmin/unmatched">
    				    	<span><i class="entypo-dot"></i><?php echo get_phrase('Unmatched_fees');?></span>
    				    </a>
                    </li>

                    <li class="<?php if($page_name == 'payment_by_degree')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/payment_by_degree">
							<span><i class="entypo-dot"></i> <?php echo get_phrase('Payment_By_Degree');?></span>
						</a>
					</li>

                    <li class="<?php if($page_name == 'payment_by_nce')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/payment_by_nce">
							<span><i class="entypo-dot"></i> <?php echo get_phrase('Payment_By_NCE');?></span>
						</a>
					</li>
				</ul>
			</li>
			<?php } ?>
            
           

           <!-- DORMITORY -->


           <!--ACCOMODATION-->
           <?php if($this->session->userdata('level') == '3' || $this->session->userdata('level') == '1' || $this->session->userdata('level') == '2'){?>
		   <li class="<?php if($page_name == 'accomodation_pins' ||
									$page_name == 'dormitory')
												echo 'opened active has-sub';?> ">
				<a href="#">
					&nbsp; <i class="fa fa-home"></i>
					<span><?php echo get_phrase('Accomodation');?></span>
				</a>
				<ul>

                	<!-- Live Etranzact -->
					<li class="<?php if($page_name == 'accomodation_pins')echo 'active';?> ">
    				    <a href="<?php echo base_url();?>index.php?sadmin/pin_info">
    				    	<span><i class="entypo-dot"></i><?php echo get_phrase('Scratch_card_info');?></span>
    				    </a>
                    </li>

                    <li class="<?php if($page_name == 'dormitory')echo 'active';?> ">
				    <!--a href="<?php echo base_url();?>index.php?sadmin/dormitory"-->
				    <a href="#">
					    <span><i class="entypo-dot"></i><?php echo get_phrase('dormitory');?></span>
				    </a>
           </li>

				</ul>
			</li>
			<?php } ?>
            
           <!-- NOTICEBOARD >
           <li class="<?php if($page_name == 'noticeboard')echo 'active';?> ">
				<a href="<?php echo base_url();?>index.php?sadmin/noticeboard">
					<i class="entypo-doc-text-inv"></i>
					<span><?php echo get_phrase('noticeboard');?></span>
				</a>
           </li-->
            
			<?php if($this->session->userdata('level') == '5'){ ?>
			<li class="<?php 
				if($page_name == 'reservedRooms' || $page_name == 'hostel_i')echo 'opened active has-sub';
				?> ">
				<a href="#">
					<i class="entypo-home"></i>
					<span><?php echo get_phrase('Hostel Allocation');?></span>
				</a>
				<ul>
					<li class="<?php if($page_name == 'reservedRooms')echo 'active';?> ">
    				    <a href="<?php echo base_url();?>index.php?sadmin/hostelAllocation/reservedRooms">
    				    	<span><i class="entypo-dot"></i><?php echo get_phrase('Reserved Rooms');?></span>
    				    </a>
                    </li>
                    <li class="<?php if($page_name == 'hostel_i')echo 'active';?> ">
						<a href="<?php echo base_url();?>index.php?sadmin/hostelAllocation/hostel_i">
							<span><i class="entypo-dot"></i><?php echo get_phrase('Hostel I');?></span>
						</a>
					</li>

				</ul>
			</li>
			<?php } ?>
           
           <!-- ACCOUNT -->
		   <?php if($this->session->userdata('hostel_allocation') != 1){ ?>
           <li class="<?php if($page_name == 'manage_profile')echo 'active';?> ">
				<a href="<?php echo base_url();?>index.php?sadmin/manage_profile">
					<i class="entypo-lock"></i>
					<span><?php echo get_phrase('account');?></span>
				</a>
           </li>   
		   <? } ?>
		</ul>
<?php }?>        		
</div>