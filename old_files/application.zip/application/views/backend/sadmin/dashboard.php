<?php

$old = $this->db->count_all('etranzact_payment');
$new = $this->db->count_all('eduportal_fee_payment');

$paid = $old + $new;


/*$this->db->select('*');
$this->db->from('student as b');
//$this->db->where('a.customer_id = b.reg_no',NULL,FALSE);
$this->db->where('b.reg_no IN (SELECT a.customer_id FROM etranzact_payment a)', NULL, FALSE);
//$this->db->where('a.idno',$reg_no);
$query = $this->db->get()->num_rows();/

$this->db->where('whatever',);
$num = $this->db->count_all_results('table');*/

?>

<?php
	/*
	$this->db->select('*');
	$this->db->from('student');
	$this->db->order_by('id', 'desc');
	$this->db->limit('10');
	
	$s = $this->db->result_array();
	
	var_dump($s);*/
?>

<?php

/*$this->db->select('*');
//$this->db->from('etranzact_payment a,student b');
$this->db->from('student as b');
//$this->db->where('a.customer_id = b.reg_no',NULL,FALSE);
$this->db->where('b.reg_no NOT IN (SELECT a.customer_id FROM etranzact_payment a)', NULL, FALSE);
//$this->db->where('a.idno',$reg_no);
$unpaid = $this->db->get()->num_rows();
$manual = $this->db->count_all('manual_etranzact');

$total = $unpaid - $manual;*/

?>
<style type="text/css">
	.num{
		font-weight:bold;
		font-family:'Roboto-Light';
		font-size:40px;
	}
	.shortcut h3{
		font-size:18px;
	}
	.widget .table-bordered{
		border:1px solid #ebebeb;
	}
	.widget .table-bordered thead{
		background:gold !important;
		/*background: -moz-linear-gradient(top, #eeeeee 0%, #dadada 100%);
		background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #eeeeee), color-stop(100%, #dadada));
		background: -webkit-linear-gradient(top, #eeeeee 0%, #dadada 100%);
		background: -o-linear-gradient(top, #eeeeee 0%, #dadada 100%);
		background: -ms-linear-gradient(top, #eeeeee 0%, #dadada 100%);
		background: linear-gradient(top, #eeeeee 0%, #dadada 100%);
		-ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr='#EEEEEE', endColorstr='#DADADA')";
		filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#EEEEEE', endColorstr='#DADADA');*/
	}
</style>

<div class="row">
	<div class="col-md-12">
		<div class="col-md-12">
			<div class="widget stacked">
				<div class="widget-content">
					<div class="shortcuts">
						<?php if($this->session->userdata('level') == '3' || $this->session->userdata('level') == '1' || $this->session->userdata('level') == '2'){?>
						<a href="javascript:;" class="shortcut col-md-2">
							<span class="shortcut-label">
								<div class="num" data-start="0" id='etti' data-end="<?php echo $paid; ?>"
								data-postfix="" data-duration="1500" data-delay="0"><?php echo $paid; ?></div>       
                    
								<h3><?php echo get_phrase('Etranzact Payment');?></h3>
							</span>
						</a>
						
						<a href="javascript:;" class="shortcut col-md-2">
							<span class="shortcut-label">
								<div class="num" data-start="0" id="unpaid" data-end="" 
								data-postfix="" data-duration="1500" data-delay="0">0</div>
						
								<h3><?php echo get_phrase('Unverified Etranzact Payment');?></h3>
							</span>								
						</a>
						<?php } ?>
						
						<a href="javascript:;" class="shortcut col-md-2">
							<span class="shortcut-label">
								<div class="num" data-start="0" data-end="<?php echo $this->db->count_all('student');?>" 
								data-postfix="" data-duration="1500" data-delay="0"><?php echo $this->db->count_all('student');?></div>
                    
								<h3><?php echo get_phrase('Registered Students');?></h3>
							</span>	
						</a>
						<?php if($this->session->userdata('level') != '5'){?>
						<a href="javascript:;" class="shortcut col-md-2">
							<span class="shortcut-label">
								<div class="num" data-start="0" id="nceT" data-end="<?php $this->db->where('programme', 'NCE'); $this->db->from('student'); echo $this->db->count_all_results(); ?>" 
								data-postfix="" data-duration="1500" data-delay="0"><?php $this->db->where('programme', 'NCE'); $this->db->from('student'); echo $this->db->count_all_results(); ?></div>
                    
								<h3><?php echo get_phrase('NCE Students');?></h3>
							</span>	
							<!--div class="row">
								<div class="co-sm-2">	0	
								<div class="co-sm-2">	0							
								</div>						
								</div>
								
							</div-->
						</a>
						<a href="javascript:;" class="shortcut col-md-2">
							<span class="shortcut-label">
								<div class="num" data-start="0" id="degreeT" data-end="<?php $this->db->where('programme', 'DEGREE'); $this->db->from('student'); echo $this->db->count_all_results(); ?>" 
								data-postfix="" data-duration="1500" data-delay="0"><?php $this->db->where('programme', 'DEGREE'); $this->db->from('student'); echo $this->db->count_all_results(); ?></div>

								<h3><?php echo get_phrase('Degree Students');?></h3>
							</span>	
						</a>
						<?php } ?>

						<?php if($this->session->userdata('level') == '3' || $this->session->userdata('level') == '1' || $this->session->userdata('level') == '2'){?>
           				<a href="javascript:;" class="shortcut col-md-2">
							<span class="shortcut-label">
								<div class="num" data-start="0" data-end="<?php echo $this->db->count_all('counter');?>" 
								data-postfix="" data-duration="1500" data-delay="0"><?php echo $this->db->count_all('counter');?></div>
                    
								<h3><?php echo get_phrase('Used Scratch Cards');?></h3>
							</span>								
						</a>
						
						<a href="javascript:;" class="shortcut col-md-2">
							<span class="shortcut-label">
								<div class="num" data-start="0" data-end="<?php echo $this->db->count_all('teacher');?>" 
								data-postfix="" data-duration="1500" data-delay="0"><?php echo $this->db->count_all('teacher');?></div>
                    
								<h3><?php echo get_phrase('Staff');?></h3>
							</span>								
						</a>
						<?php } ?>
					</div> <!-- /shortcuts -->	
				
				</div> <!-- /widget-content -->
				
			</div> 
		</div>
		<div class="col-md-6">
			<div class="widget stacked">
					
				<div class="widget-header">
					<i class="icon-check"></i>
					<h3>Event Schedule</h3>
				</div> <!-- /widget-header -->
				
				<div class="widget-content">
					<div class="calendar-env">
						<div class="calendar-body">
							<div id="notice_calendar"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="widget stacked widget-table">
					
				<div class="widget-header">
					<i class="icon-info-sign"></i>
					<h3>Latest Student Registration</h3>
				</div> <!-- /widget-header -->
				
				<div class="widget-content">
					
					<table class="table table-bordered mytable">
						<thead>
							<tr>
								<th>Name</th>
								<th>Reg No</th>
								<th class="td-actions">Date of Reg</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($reg as $row):?>
							<tr>
								<td><?php echo $row['name'].','.$row['othername'];?></td>
								<td><?php echo $row['reg_no'];?></td>
								<td class="td-actions">
									<a href="javascript:;">
										<?php echo $row['date_reg'];?> 										
									</a>
								</td>
							</tr>
							<?php endforeach;?>
						</tbody>
					</table>
					
				</div> <!-- /widget-content -->
			
			</div> 
			<?php if($this->session->userdata('level') == '3' || $this->session->userdata('level') == '1' || $this->session->userdata('level') == '2'){?>
			<div class="widget widget-nopad stacked">
						
				<div class="widget-header">
					<i class="icon-list-alt"></i>
					<h3>Recent News</h3>
				</div> <!-- /widget-header -->
				
				<div class="widget-content">
					
					<ul class="news-items">
						<li>
							
							<div class="news-item-detail">										
								<a href="javascript:;" class="news-item-title">Duis aute irure dolor in reprehenderit</a>
								<p class="news-item-preview">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
							</div>
							
							<div class="news-item-date">
								<span class="news-item-day">08</span>
								<span class="news-item-month">Mar</span>
							</div>
						</li>
					</ul>
					
				</div> <!-- /widget-content -->
			
			</div>
			
			<div class="widget stacked widget-table">
					
				<div class="widget-header">
					<i class="icon-info-sign"></i>
					<h3>Latest Accommodation Allocation</h3>
				</div> <!-- /widget-header -->
				
				<div class="widget-content">
					
					<table class="table table-bordered mytable">
						<thead>
							<tr>
								<th>Hostel</th>
								<th>Room</th>
								<th class="td-actions">Assigned To</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($hostel as $row):?>
							<tr>
								<td><?php echo $row['hostel_name'];?></td>
								<td><?php echo $row['room_no'];?></td>
								<td class="td-actions">
									<a href="javascript:;">
										<?php echo $row['idno'];?>										
									</a>
								</td>
							</tr>
							<?php endforeach;?>
						</tbody>
					</table>
					
				</div> <!-- /widget-content -->
			
			</div>
			
			<div class="widget stacked widget-table">
					
				<div class="widget-header">
					<i class="icon-info-sign"></i>
					<h3>Latest E-Tranzact Payment</h3>
				</div> <!-- /widget-header -->
				
				<div class="widget-content">
					
					<table class="table table-bordered mytable">
						<thead>
							<tr>
								<th>Payment For</th>
								<th>Date</th>
								<th class="td-actions">Paid By</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($etz as $row):?>
							<tr>
								<td><?php echo $row['description'];?></td>
								<td><?php echo $row['payment_date'];?></td>
								<td class="td-actions">
									<a href="javascript:;">
										<?php echo $row['customer_id'];?>										
									</a>
								</td>
							</tr>
							<?php endforeach;?>
						</tbody>
					</table>
					
				</div> <!-- /widget-content -->
			
			</div>
			<?php } ?>
		</div>
	</div>
    
    
</div>



    <script>
  $(document).ready(function() {
      
      var calendar = $('#notice_calendar');
                
                $('#notice_calendar').fullCalendar({
                    header: {
                        left: 'title',
                        right: 'today prev,next'
                    },
                    
                    //defaultView: 'basicWeek',
                    
                    editable: false,
                    firstDay: 1,
                    height: 530,
                    droppable: false,
                    
                    events: [
                        <?php 
                        $notices    =   $this->db->get('noticeboard')->result_array();
                        foreach($notices as $row):
                        ?>
                        {
                            title: "<?php echo $row['notice_title'];?>",
                            start: new Date(<?php echo date('Y',$row['create_timestamp']);?>, <?php echo date('m',$row['create_timestamp'])-1;?>, <?php echo date('d',$row['create_timestamp']);?>),
                            end:    new Date(<?php echo date('Y',$row['create_timestamp']);?>, <?php echo date('m',$row['create_timestamp'])-1;?>, <?php echo date('d',$row['create_timestamp']);?>) 
                        },
                        <?php 
                        endforeach
                        ?>
                        
                    ]
                });
    });
  </script>



<script type="text/javascript">
$(document).ready(function() {
    setTimeout(function(){
    $.ajax({
    url: "<?php echo base_url().'index.php?admin/display';?>",
    type: 'POST',
    dataType : 'json',
    //data: {name: result},
    success: function(res) {
    if (res)
    {
    console.log('PASSED');
    jQuery("div#etti").html(res.name);
    }
    },
    error : function () {
        console.log('failure');
    }
})

},10);
});
</script>



<script type="text/javascript">
$(document).ready(function() {
      //var querydb = $("form").serialize();
    $.ajax({
    url: "<?php echo base_url().'index.php?admin/display_un';?>",
    type: 'POST',
    dataType : 'json',
    //data: {name: result},
    success: function(res) {
    if (res)
    {
    console.log('PASSED');
    jQuery("div#unpaid").html(res.name);
    }
    },
    error : function () {
        console.log('failure');
    }
});
});
</script>

<script type="text/javascript">
$(document).ready(function() {
    $.ajax({
    url: "<?php echo base_url().'index.php?admin/nce';?>",
    type: 'POST',
    dataType : 'json',
    success: function(res) {
    if (res)
    {
    console.log('PASSED');
    jQuery("div#nceT").html(res.name);
    }
    },
    error : function () {
        console.log('failure');
    }
});
});
</script>

<script type="text/javascript">
$(document).ready(function() {
    $.ajax({
    url: "<?php echo base_url().'index.php?admin/degree';?>",
    type: 'POST',
    dataType : 'json',
    success: function(res) {
    if (res)
    {
    console.log('PASSED');
    jQuery("div#degreeT").html(res.name);
    }
    },
    error : function () {
        console.log('failure');
    }
});
});
</script>
