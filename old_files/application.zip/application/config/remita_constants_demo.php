<?php
define("MERCHANTID", "2547916");
define("SERVICETYPEID", "4430731");
define("APIKEY", "1946");
define("GATEWAYURL", "http://www.remitademo.net/remita/ecomm/v2/init.reg");
define("GATEWAYRRRPAYMENTURL", "http://www.remitademo.net/remita/ecomm/finalize.reg");
define("CHECKSTATUSURL", "http://www.remitademo.net/remita/ecomm");
define("PATH", 'http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']));
?>