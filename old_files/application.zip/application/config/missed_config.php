<?php

$config['possible_permissions']=array('employees','skills','performance','discipline','timeoff','admin','recruiting','reports','documents');

$config['encrypt_cipher']  = 'rijndael-128';
?>