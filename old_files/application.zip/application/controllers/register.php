<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
     session_start();
/*
 *  @author : Emmanuel Etti
 *  @contributor : Sunday Okoi
 *  18th January, 2015
 *  Eduportal
 *  www.autopathgrp.com
 *
 */


class Register extends CI_Controller
{


    function __construct()
    {
        parent::__construct();
        $this->load->model('crud_model');
        $this->load->database();
        /*cache control*/
        $this->output->set_header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->output->set_header("Expires: Mon, 26 Jul 2010 05:00:00 GMT");
    }

    //Default function, redirects to logged in user area
    public function index()
    {
		

        if ($this->session->userdata('admin_login') == 1)
            redirect(base_url() . 'index.php?admin/dashboard', 'refresh');

        if ($this->session->userdata('sadmin_login') == 1)
            redirect(base_url() . 'index.php?sadmin/dashboard', 'refresh');

        if ($this->session->userdata('teacher_login') == 1)
            redirect(base_url() . 'index.php?teacher/dashboard', 'refresh');

        if ($this->session->userdata('student_login') == 1)
            redirect(base_url() . 'index.php?student/dashboard', 'refresh');

        if ($this->session->userdata('parent_login') == 1)
            redirect(base_url() . 'index.php?parents/dashboard', 'refresh');
          $page_data['page_name']  = 'register';
          $page_data['page_title'] = get_phrase('Federal Polytechnic Nekede');
     $this->load->view('backend/register', $page_data);

    }


    public function account_verification()
    {
		

        if ($this->session->userdata('admin_login') == 1)
            redirect(base_url() . 'index.php?admin/dashboard', 'refresh');

        if ($this->session->userdata('sadmin_login') == 1)
            redirect(base_url() . 'index.php?sadmin/dashboard', 'refresh');

        if ($this->session->userdata('teacher_login') == 1)
            redirect(base_url() . 'index.php?teacher/dashboard', 'refresh');

        if ($this->session->userdata('student_login') == 1)
            redirect(base_url() . 'index.php?student/dashboard', 'refresh');

        if ($this->session->userdata('parent_login') == 1)
            redirect(base_url() . 'index.php?parents/dashboard', 'refresh');
          $page_data['page_name']  = 'portal_account_verification';
          $page_data['page_title'] = get_phrase('Federal Polytechnic Nekede | Account Verification');
     $this->load->view('backend/register', $page_data);

    }
    /*public function register()
    {     //$page_data['teachers']   = $this->db->get('teacher')->result_array();
        $page_data['page_name']  = 'register';
        $page_data['page_title'] = get_phrase('Alvan Ikoku College of Education | Register');
         $this->load->view('backend/register', $page_data);
    }*/
	function process_account_verification()
	{
		session_start();
		$st_type = $this->input->post('st_type');
		if($st_type==1)
		{
		$serial = $this->input->post('serial1');	
		$adm_exist = $this->db->get_where('eduportal_admission_list', array("application_no" => $serial))->row();
		
		if($adm_exist){
			$student = $this->db->get_where('student', array("portal_id" => $serial))->row();
			if(!$student)
			 {
			$data["name"]=$adm_exist->surname;
			$data["othername"]=$adm_exist->firstname." ".$adm_exist->middlename;
			$data["reg_no"]=$adm_exist->application_no;
			$data["portal_id"]=$adm_exist->application_no;
			$data["password"]="12345";
			$data["dept"]=$adm_exist->dept_id;
			$data["school"]=$adm_exist->school_id;
			$data["programme"]=$adm_exist->student_type;
			$data["prog_type"]=$adm_exist->programme_type_id;
			$_SESSION['app_no'] = $serial;
			$_SESSION['st_type'] = '1';
			$result=$this->db->insert('student',$data);
			//$score =$alreadyRecorded->screening_result;
			//echo $result;
				redirect(base_url() . 'index.php?register/portal_account_slip');
			 }
			else
			 {
			$_SESSION['app_no'] = $serial;
			$_SESSION['st_type'] = '1';
			//echo '1';
			redirect(base_url() . 'index.php?register/portal_account_slip');
			 }
			}
			else
			{
			$_SESSION['error'] = 'Sorry Application Form No does not Exist in Admissions List! Please Contact ICT Unit';
			redirect(base_url() . 'index.php?register/account_verification');
			}
		
		
		}
		else
		{
		$serial = $this->input->post('serial2');
		$student_exist = $this->db->get_where('eduportal_students_record', array("regno" => $serial))->row();
		if($student_exist){
			$student = $this->db->get_where('student', array("portal_id" => $serial))->row();
			if(!($student))
			{
			$data["name"]=$student_exist->surname;
			$data["othername"]=$student_exist->firstname." ".$adm_exist->middlename;
			$data["reg_no"]=$student_exist->regno;
			$data["portal_id"]=$student_exist->regno;
			$data["password"]="12345";
			$data["dept"]=$student_exist->dept_id;
			$data["school"]=$student_exist->school_id;
			$data["programme"]=$student_exist->student_type_id;
			$data["prog_type"]=$student_exist->programme_type_id;
			
			$this->db->insert('student',$data);
			$_SESSION['app_no'] = $serial;
			$_SESSION['st_type'] = '2';
			//$score =$alreadyRecorded->screening_result;
			//echo "<pre>".print_r($data)."</pre>";
				redirect(base_url() . 'index.php?register/portal_account_slip');
			}
			else
			{
				$_SESSION['app_no'] = $serial;
			$_SESSION['st_type'] = '2';
			//$score =$alreadyRecorded->screening_result;
			
				redirect(base_url() . 'index.php?register/portal_account_slip');
			}
			}
			else
			{
			$_SESSION['error'] = 'Sorry Registration/Matric No does not Exist in Students Record! Please Contact ICT Unit!';
			redirect(base_url() . 'index.php?register/account_verification');
			}
		}
		
		//echo $st_type." ".$serial;
		
		
	}
	
	function portal_account_slip()
	{
		 $page_data['page_name']  = 'portal_account_notification_slip';
     
        $page_data['page_title'] = get_phrase('Federal Polytechnic Nekede | Portal Account Notification Slip');
         $this->load->view('backend/student_print', $page_data); 
	}
function createaccountfromoutside()
	{
		 $page_data['page_name']  = 'createaccountfromoutside';
     
        $page_data['page_title'] = get_phrase('Federal Polytechnic Nekede | Create Portal Account');
         $this->load->view('backend/student_print', $page_data); 
	}
	
		function access(){
		$this->session->set_userdata('access', 1);
		redirect(base_url() . 'index.php?student/hostel', refresh);

	}
	
function createportalaccountfromoutside()
	{
		session_start();
		$portalID = $this->input->post('portal_id');
		$lname = $this->input->post('lastname');
		$firstname = $this->input->post('firstname');
		$middlename = $this->input->post('middlename');
		$student = $this->db->get_where('student', array("portal_id" => $portalID))->row();
			if(!$student)
			 {
		
			$data['name']        = $this->input->post('name');
            $data['othername']   = $this->input->post('othername');
			$data["reg_no"]=$portalID ;
			$data["portal_id"]=$portalID;
			$data["password"]="12345";
			$data['dept']        = $this->input->post('dept');
            $data['programme']   = $this->input->post('programme');
            $data['school']      = $this->input->post('school');
            $data['prog_type']   = $this->input->post('prog_type');
			$data['phone']       = $this->input->post('phone');
            $data['email']       = $this->input->post('email');
			$data['status']       = '2';
			
			//$data["prog_type"]=$this->input->post('middlename');
			
			$_SESSION['app_no'] = $portalID;
			$_SESSION['st_type'] = '1';
			$_SESSION['fee_type'] = $this->input->post('paymentType');
			$result=$this->db->insert('student',$data);
			//$score =$alreadyRecorded->screening_result;
			//echo $result;
			$credential2	=	array(	'portal_id' => $portalID  );
			$query = $this->db->get_where('student' , $credential2);

        if ($query->num_rows() > 0) {

            $row = $query->row();
		}
			
			$this->session->set_userdata('student_login', '1');

			  $this->session->set_userdata('student_id', $row->student_id);

			  $this->session->set_userdata('name', $row->name);
			  
			  $this->session->set_userdata('oname', $row->othername);
			  
			  $this->session->set_userdata('fullname', $row->name.', '.$row->othername);

			  $this->session->set_userdata('reg_no', $row->reg_no);
			  
			  $this->session->set_userdata('email', $row->email);

			  $this->session->set_userdata('phone', $row->phone);
			  
			  $this->session->set_userdata('portal_id', $row->portal_id);

			  $this->session->set_userdata('login_type', 'student');
			
				$credential2	=	array(	'portal_id' => $portalID  );
			$query = $this->db->get_where('student' , $credential2);

        if ($query->num_rows() > 0) {

            $row = $query->row();
		}
			
			$this->session->set_userdata('student_login', '1');

			  $this->session->set_userdata('student_id', $row->student_id);

			  $this->session->set_userdata('name', $row->name);
			  
			  $this->session->set_userdata('oname', $row->othername);
			  
			  $this->session->set_userdata('fullname', $row->name.', '.$row->othername);

			  $this->session->set_userdata('reg_no', $row->reg_no);
			  
			  $this->session->set_userdata('email', $row->email);

			  $this->session->set_userdata('phone', $row->phone);
			  
			  $this->session->set_userdata('portal_id', $row->portal_id);

			  $this->session->set_userdata('login_type', 'student');
			
				redirect(base_url() . 'index.php?register/portal_account_slip');
			 }
			else
			 {
			$_SESSION['app_no'] = $portalID;
			$_SESSION['st_type'] = '2';
			$_SESSION['fee_type'] = $this->input->post('paymentType');
			
			
			//echo '1';
			redirect(base_url() . 'index.php?register/portal_account_slip');
			 }
			
	}
    function password($param1 = '', $param2 = '', $param3 = '')
    {
		
		
        //if ($this->session->userdata('admin_login') != 1)
            //redirect(base_url(), 'refresh');
        $this->session->set_userdata('etti','etti');
        if ($param1 == 'forgot') {
            $reg                 = $this->input->post('name');
            $phone               = $this->input->post('phone');
            $check = $this->db->get_where('student', array('reg_no' => $reg,'phone'=>$phone))->row();
            

            if($check){
                if($this->session->userdata('etti')){
                $this->load->library('ozioma'); //load the ozioma library  $this->input->post('message')
                $this->ozioma->set_message("Hello ".$reg.", Your password is ".$check->password.". Please login with your Reg/Matric No and password.");//message from textfield
                $this->ozioma->set_recipient($check->phone);//separate numbers with commas and include zip code in every number
                $this->ozioma->set_sender("FPN EDUPORTAL");//sender from database
                        //echo "am here too";
                $this->session->unset_userdata('etti');
                $this->ozioma->send();
            }

                $_SESSION['err_msg'] = "The message has been sent...";
                $_SESSION['etti'] = 'pishaun';
                redirect(base_url() . 'index.php?register/password');
            }else{
               $_SESSION['err_msg'] = "Sorry: Reg No/ Matric Number and phone number combination is incorrect, please enter the correct reg number and the phone number used during registration..."; 
            }
            
            //$this->db->insert('teacher', $data);
            //$teacher_id = mysql_insert_id();
            //move_uploaded_file($_FILES['userfile']['tmp_name'], 'uploads/teacher_image/' . $teacher_id . '.jpg');
            //$this->email_model->account_opening_email('teacher', $data['email']); //SEND EMAIL ACCOUNT OPENING EMAIL
            //redirect(base_url(), 'refresh');
            

            
        }
        $page_data['page_name'] = 'forgot_password';
        $page_data['page_title'] = get_phrase('Federal Polytechnic Owerri | Forgor Password');
        $this->load->view('backend/register', $page_data);
    }

    public function register1()
    {     //$page_data['teachers']   = $this->db->get('teacher')->result_array();

		
	
        $page_data['user']    = $_SESSION['user'];
        session_unset($_SESSION['user']);
        //$page_data['page_name']  = 'register2';
        //$page_data['page_title'] = get_phrase('Alvan Ikoku College of Education | Register');
         $this->load->view('backend/login1', $page_data);

         //$this->load->view('backend/login');
    }


    public function register2()
    {
		
		
		
      if(!isset($_SESSION['register2'])){
    header('Location:index.php?register');
    }
        if(!$this->input->post('submit')){
        $page_data['user']    = $_SESSION['user'];

         $page_data['page_name']  = 'register1';
         $page_data['page_title'] = get_phrase('Alvan Ikoku College of Education | Register');
         $this->load->view('backend/register', $page_data);
        }
        else{
           $page_data['fname']        = strtoupper($this->input->post('fname'));
           $page_data['name']        = strtoupper($this->input->post('name'));
            $page_data['address']     = $this->input->post('address');
            $page_data['reg_no']     = $this->input->post('reg_no');
            $page_data['phone']       = $this->input->post('phone');
            $page_data['email']       = $this->input->post('email');
            $page_data['title']       = $this->input->post('title');
            $page_data['password']       = $this->input->post('password');
            $page_data['password_c']      = $this->input->post('password_c');

		if(($page_data['password'] == $page_data['password_c']) && (is_numeric($page_data['phone'])) && (filter_var($page_data['email'], FILTER_VALIDATE_EMAIL))){

			$countries = $this->db->get("countries");
			$conlist = $countries->result_array();

			$_SESSION['register3'] = 'register3';
			$page_data['country']  = $conlist;
			$page_data['page_name']  = 'register2';
			$page_data['page_title'] = get_phrase('Alvan Ikoku College of Education | Register');
			$this->load->view('backend/register', $page_data);
		}
      else{
        //$_SESSION['err_msg'] = "Your passwords do  not match.";
        //$page_data['pwd_verify'] = "Your passwords do  not match";
        //$this->load->view('backend/register/register1');

        $page_data['error'] = "One or more of the following errors may have occured. <br /> &nbsp; &nbsp; \\\ Your passwords do  not match, <br /> &nbsp; &nbsp; \\\ Your phone number input is not a number, <br /> &nbsp; &nbsp; \\\ Your email input is not a valid email address. <br /> Please review and input again.";
        $page_data['fname'] = $page_data['fname'];
        $page_data['name'] = $page_data['name'];
        $page_data['user'] = $page_data['reg_no'];
        $page_data['phone'] = $page_data['phone'];
        $page_data['email'] = $page_data['email'];
        $page_data['title'] = $page_data['title'];
        $page_data['address'] = $page_data['address'];

        $page_data['page_name']  = 'register1';
        $page_data['page_title'] = get_phrase('Alvan Ikoku College Of Education | Register');
        $this->load->view('backend/register', $page_data);
      }
        }
    }

    public function register21()
    {
		
		
		
    if(!isset($_SESSION['user'])){
    header('Location:index.php?register');
    }
         $page_data['user']    = $_SESSION['user'];

         $page_data['page_name']  = 'register2';
         $page_data['page_title'] = get_phrase('Alvan Ikoku College of Education | Register');
         $this->load->view('backend/register', $page_data);
    }

    public function register3($param1 = '', $param2 = '', $param3 = '')
    {
		
		
		
        if(!isset($_SESSION['register3'])){
    header('Location:index.php?register');
    }
    unset($_SESSION['register2']);
         if($param1 == 'info'){
			if(!isset($_SESSION['ertti'])){
            $data['name']        = $this->input->post('name');
            $data['othername']   = $this->input->post('fname');
            $data['birthday']    = $this->input->post('birthday');
            $data['sex']         = $this->input->post('sex');
            $data['religion']    = $this->input->post('religion');
            $data['blood_group'] = $this->input->post('blood_group');
            $data['address']     = $this->input->post('address');
            $data['reg_no']     = $this->input->post('reg_no');
            $data['phone']       = $this->input->post('phone');
            $data['email']       = $this->input->post('email');
            $data['marital_status']       = $this->input->post('marital_status');
            $data['nationality'] = $this->input->post('nationality');
            $data['state']       = $this->input->post('state');
            $data['title']       = $this->input->post('title');
            $data['country']       = $this->input->post('country');
            $data['lga']         = $this->input->post('lga');
            $data['dept']        = $this->input->post('dept');
            $data['programme']   = $this->input->post('programme');
            $data['school']      = $this->input->post('school');
            $data['prog_type']   = $this->input->post('prog_type');
            $data['level']       = $this->input->post('level');
            $data['semester']    = $this->input->post('semester');
            $data['parent_name']        = $this->input->post('parent_name');
            $data['parent_phone']       = $this->input->post('parent_phone');
            $data['parent_address']     = $this->input->post('parent_address');
            $data['password']     = $this->input->post('password');
            $data['date_reg']     = date("Y-m-d h:i:s");


            //$page_data['page_title'] = get_phrase('Alvan Ikoku College of Education | Register');
            //$this->load->view('backend/register', $page_data);
			$_SESSION['ertti'] = 'etti';
            $this->db->insert('student', $data);
            $student_id = mysql_insert_id();

            $_SESSION['id'] = $student_id;
            $_SESSION['phone'] = $data['phone'];
            $_SESSION['address'] = $data['address'];
            $_SESSION['dept'] = $data['dept'];
            $_SESSION['level'] = $data['level'];
            $_SESSION['prog'] = $data['prog_type'];
            $_SESSION['password'] = $data['password'];
            $_SESSION['fullname'] = $data['name'] . " " . $data['othername'];
            $_SESSION['reg'] = $data['reg_no'];

			}
            header('Location:index.php?register/register3');
		 
         }
        if($param1 == 'picture'){
      $student_id = $_SESSION['id'];
			
      $max_file_size = 51200;

      $imagesize = $_FILES['userfile']['size'];
      $signsize = $_FILES['usersign']['size'];

      if($imagesize > $max_file_size){
        $_SESSION['imgerror'] = "Passport image size is too large. Please upload an image less than 50kb";
        $page_data['page_name']  = 'register3';
        $page_data['page_title'] = get_phrase('Alvan Ikoku College of Education | Register');
        header('Location:index.php?register/register3');
        //$this->load->view('backend/register', $page_data);
      }elseif($signsize > $max_file_size){
        $_SESSION['imgerror'] = "Signature image size is too large. Please upload an image less than 50kb";
        $page_data['page_name']  = 'register3';
        $page_data['page_title'] = get_phrase('Alvan Ikoku College of Education | Register');
        header('Location:index.php?register/register3');
        //$this->load->view('backend/register', $page_data);
      }else{
        move_uploaded_file($_FILES['userfile']['tmp_name'], 'uploads/student_image/' . $student_id . '.jpg');
        $this->crud_model->clear_cache();
        $_SESSION['image'] = 'uploads/student_image/' . $student_id . '.jpg';

        move_uploaded_file($_FILES['usersign']['tmp_name'], 'uploads/student_signature/' . $student_id . '.jpg');
        $_SESSION['signature'] = 'uploads/student_signature/' . $student_id . '.jpg';
        $this->crud_model->clear_cache();
        $_SESSION['register4'] = "register4";
        header('Location:index.php?register/register4');
      }

          //move_uploaded_file($_FILES['userfile']['tmp_name'], 'uploads/student_image/' . $student_id . '.jpg');
          //$this->crud_model->clear_cache();
          //$_SESSION['image'] = 'uploads/student_image/' . $student_id . '.jpg';
          //$imagesize = getImageSize($_SESSION['image']);

          /*move_uploaded_file($_FILES['usersign']['tmp_name'], 'uploads/student_signature/' . $student_id . '.jpg');
          $_SESSION['signature'] = 'uploads/student_signature/' . $student_id . '.jpg';
          $this->crud_model->clear_cache();
          header('Location:index.php?register/register4');*/
        }

        $page_data['page_name']  = 'register3';
        $page_data['page_title'] = get_phrase('Alvan Ikoku College of Education | Register');
         $this->load->view('backend/register', $page_data);
		$this->session->set_userdata('ph','08131342381');

            /*var_dump($student_id);
            move_uploaded_file($_FILES['userfile']['tmp_name'], 'uploads/student_image/' . $student_id . '.jpg');
            $this->email_model->account_opening_email('student', $data['email']); //SEND EMAIL ACCOUNT OPENING EMAIL
            redirect(base_url() . 'index.php?admin/student_add/' . $data['class_id'], 'refresh');


         redirect(base_url().'index.php?register/register3' , 'refresh'); */
    }

    public function register4()
    {
		
		
	unset($_SESSION['ertti']);
    if(!isset($_SESSION['register4'])){
    header('Location:index.php?register');
    }
    unset($_SESSION['register3']);
    unset($_SESSION['imgerror']);
        $page_data['reg_no']  = $_SESSION['reg'];
        $_SESSION['page'] = 'ozioma';
        //$page_data['page_name']  = 'register4';
        $page_data['page_name']  = 'register4';
        $page_data['page_title'] = get_phrase('Alvan Ikoku College of Education | Register');
         $this->load->view('backend/register', $page_data);
    }

    public function register5($param1 = '', $param2 = '', $param3 = '')
    {
		
		
		
    if(!isset($_SESSION['user'])){
    header('Location:index.php?register');
    }
	
    $sid = $_SESSION['id'];
    if($param1 == 'e'){
			unset($_SESSION['register4']);
			
			$this->load->library('etranzact'); //load the ozioma library  $this->input->post('message')
			$this->etranzact->set_terminal($this->input->post('TERMINAL_ID'));//message from textfield
			$this->etranzact->set_conf($this->input->post('CONFIRMATION_NO'));//message from textfield
			$this->session->set_userdata('level',$_SESSION['level']);
			$this->session->set_userdata('session',$this->input->post('session'));
			//$this->session->set_userdata('conff',$this->input->post('CONFIRMATION_NO'));
			$this->session->set_userdata('serial',$this->input->post('serial'));
			$this->session->set_userdata('address',$_SESSION['address']);
			$this->session->set_userdata('phone',$_SESSION['phone']);
			$this->session->set_userdata('image',$_SESSION['image']);
			$this->session->set_userdata('signature',$_SESSION['signature']);
			$this->session->set_userdata('prog',$_SESSION['prog']);
			$this->session->set_userdata('dept',$_SESSION['dept']);
			$this->session->set_userdata('password',$_SESSION['password']);

			$check = $this->db->get_where('etranzact_payment', array('customer_id' => $this->session->userdata('serial'),'confirm_code'=>$this->input->post('CONFIRMATION_NO')))->row();
			if(!$check){ //check if student has not registered
				$check = $this->db->get_where('etranzact_payment', array('confirm_code'=>$this->input->post('CONFIRMATION_NO')))->result_array();
				//var_dump($check);
				//if( !empty($check) && $check->customer_id != $this->session->userdata('serial')){
				if($check){
					$_SESSION['err_msg'] = "Sorry: The Confirmation Code is Invalid, it has been used by another Student...";
				}else {
					$this->etranzact->send();
					//var_dump($this->session->userdata('fullname'));
					if($this->etranzact->get_status() != "-1"){  //start etranzact check

						$this->session->set_userdata('receipt',$this->etranzact->get_receipt()); //Trans Receipt
						$this->session->set_userdata('fullname',$this->etranzact->get_fullname()); //Student Name
						$this->session->set_userdata('bankcode',$this->etranzact->get_bankcode()); //Bank Code
						$this->session->set_userdata('bankname',$this->etranzact->get_bankname());  //Bank Name
						$this->session->set_userdata('branchcode',$this->etranzact->get_branchcode());//Branch Code
						$this->session->set_userdata('conff',$this->etranzact->get_confirm());
						$this->session->set_userdata('amount',$this->etranzact->get_amount());//transaction Amount
						$this->session->set_userdata('descr',$this->etranzact->get_descr());  //Transaction Description
						$this->session->set_userdata('date',$this->etranzact->get_date());    //Transaction Date


						/*start ozioma sms*/
						if($this->etranzact->get_status() != "-1"){
						//echo "am here";
							if($this->session->userdata('ph')){
							//var_dump($_SESSION['page']);
							//var_dump($this->session->userdata('phone'));
								$this->load->library('ozioma'); //load the ozioma library  $this->input->post('message')
								$this->ozioma->set_message("Hello ".$this->session->userdata('fullname').", Your fee has been successfully processed for the ".   $this->session->userdata('session')." Session. And your login details are: ".$this->session->userdata('serial')." & password: ".$this->session->userdata('password'));//message from textfield
								$this->ozioma->set_recipient($this->session->userdata('phone'));//separate numbers with commas and include zip code in every number
								$this->ozioma->set_sender("Alvan Reg");//sender from database
								$this->ozioma->send();
								$this->session->unset_userdata('ph');
								if(!$this->ozioma->get_status() == 'OK'){
									/// exit($this->load->view('layout/error',array('message'=>$this->form_validation->error_string()),TRUE));
								}
							}
							//end ozioma
						}

						$data['customer_id'] =  $this->session->userdata('serial');
                        $data['date_reg'] =  date("Y-m-d");
						$data['fullname'] =  $this->session->userdata('fullname');
						$data['receipt_no'] =  $this->session->userdata('receipt');
						$data['confirm_code'] = $this->session->userdata('conff');
						$data['description'] = $this->session->userdata('descr');
						$data['amount'] =    $this->session->userdata('amount');
						$data['phone'] =    $this->session->userdata('phone');
						$data['prog_type'] =      $this->session->userdata('prog');
						$data['dept'] =      $this->session->userdata('dept');
						$data['level'] =      $this->session->userdata('level');
						$data['session'] =      $this->session->userdata('session');
                        $data['bankname'] =  $this->session->userdata('bankname');
						$data['bankcode'] =  $this->session->userdata('bankcode');
						$data['branchcode'] =  $this->session->userdata('branchcode');
						$data['cust_add'] =     $this->session->userdata('address');
						$data['payment_date'] =   $this->session->userdata('date');
						$data['used_by'] =      $this->session->userdata('serial');
						$data['status'] =       "paid";

						$this->db->insert('etranzact_payment', $data);


						//$invoice_id                = $_POST['custom'];
						//$this->db->where('invoice_id', $invoice_id);
						//$this->db->update('invoice', $data);
						$_SESSION['err_msg'] = "Correct Pin / Serial Number Combination.";
						$link = '<a target ="_blank" href='.base_url().'index.php?student/printe/fee>Click here to print reciept for your fees</a>';
						$_SESSION['prn_msg'] = $link;
					}else if($this->etranzact->get_status() == "-1"){
						$_SESSION['err_msg'] = "Sorry: The Confirmation Code is Invalid...";
					}else if($this->etranzact->get_status() == "00"){
						$_SESSION['err_msg'] = "The server is down at the Moment, Please try again in an hour.";
					}//end etranzact check
                }
            }else{ //if he has registered retrieve data from database
              $payment =  $this->db->get_where('etranzact_payment', array('customer_id' => $this->session->userdata('serial')))->row();
				//var_dump($payment);
			   $this->session->set_userdata('fullname',$payment->fullname);
			   $this->session->set_userdata('bankcode',$payment->bankcode);
			   $this->session->set_userdata('bankname',$payment->bankname);
			   $this->session->set_userdata('branchcode',$payment->branchcode);
			   $this->session->set_userdata('conff',$payment->confirm_code);
			   $this->session->set_userdata('amount',$payment->amount);
			   $this->session->set_userdata('descr',$payment->description);
			   $this->session->set_userdata('date',$payment->payment_date);
			   $this->session->set_userdata('receipt',$payment->receipt_no);
			   $this->session->set_userdata('session',$payment->session);
               $this->session->set_userdata('image',$this->crud_model->get_image_url('student',$sid));//
               $this->session->set_userdata('signature',$this->crud_model->get_sign_url('student',$sid));
			   //$this->session->set_userdata('conf',$payment->confirm_code);
			   $this->session->set_userdata('address',$payment->cust_add);
			   $this->session->set_userdata('phone',$payment->phone);
			   $this->session->set_userdata('dept',$payment->dept);
			   $this->session->set_userdata('level',$payment->level);
			   //$this->session->set_userdata('ph','08131342381');
			   
			   if($this->etranzact->get_status() != "-1"){
				//echo "am here";
				//$_SESSION['page'] = 'k';
					if($this->session->userdata('ph')){
					//var_dump($_SESSION['page']);
					//var_dump($this->session->userdata('phone'));
						$this->load->library('ozioma'); //load the ozioma library  $this->input->post('message')
						$this->ozioma->set_message("Hello ".$this->session->userdata('fullname').", Your fee has been successfully processed for the ".   $this->session->userdata('session')." Session. And your login details are: ".$this->session->userdata('serial')." & password: ".$this->session->userdata('password'));//message from textfield
						$this->ozioma->set_recipient($this->session->userdata('phone'));//separate numbers with commas and include zip code in every number
						$this->ozioma->set_sender("Alvan Reg");//sender from database
						//echo "am here too";
						$this->ozioma->send();
						unset($_SESSION['page']);
						if(!$this->ozioma->get_status() == 'OK'){
							/// exit($this->load->view('layout/error',array('message'=>$this->form_validation->error_string()),TRUE));
						}
					}
					//end ozioma
				}
						
			   $_SESSION['err_msg'] = "This Etranzact Confirmation Code was previously been used You...";
			   $link = '<a target ="_blank" href='.base_url().'index.php?student/printe/fee>Click here to print reciept for your fees</a>';
			   $_SESSION['prn_msg'] = $link;
            }//end

        }// end of param e

        if($param1 == 'm'){
	      unset($_SESSION['register4']);
          $manual = $this->db->get_where('manual_payment', array('payment_code'=>$this->input->post('CONFIRMATION_NO')))->row();
          //var_dump($manual);
          if($manual){
            //echo "proceed to print page";
            $verify = $this->db->get_where('manual_etranzact', array('confirm_code'=>$this->input->post('CONFIRMATION_NO')))->row();//if exists
            $check = $this->db->get_where('manual_etranzact', array('confirm_code'=>$this->input->post('CONFIRMATION_NO'),'customer_id'=>$this->input->post('serial')))->row();//if exist and assigned to a student

            $this->session->set_userdata('level',$_SESSION['level']);
            $this->session->set_userdata('session',$this->input->post('session'));
            //$this->session->set_userdata('conff',$this->input->post('CONFIRMATION_NO'));
            $this->session->set_userdata('serial',$this->input->post('serial'));
            $this->session->set_userdata('address',$_SESSION['address']);
            $this->session->set_userdata('phone',$_SESSION['phone']);
            $this->session->set_userdata('image',$_SESSION['image']);
            $this->session->set_userdata('signature',$_SESSION['signature']);
            $this->session->set_userdata('dept',$_SESSION['dept']);
			$this->session->set_userdata('prog',$_SESSION['prog']);
            $this->session->set_userdata('password',$_SESSION['password']);
            $this->session->set_userdata('fullname',$_SESSION['fullname']); //get from student input
            $this->session->set_userdata('bankcode',$manual->merchant_code); //get from student input
            $this->session->set_userdata('bankname','');
            $this->session->set_userdata('branchcode','');
            $this->session->set_userdata('receipt',$manual->trans_no);
            $this->session->set_userdata('conff',$manual->payment_code);
            $this->session->set_userdata('amount',$manual->trans_amount);
            $this->session->set_userdata('descr',$manual->trans_descr);
            $this->session->set_userdata('date',$manual->trans_date);

            if($verify){
              if($check){
                //echo "retriving from database";
                $this->session->set_userdata('level',$check->level);
                $this->session->set_userdata('session',$check->session);
                //$this->session->set_userdata('conff',$this->input->post('CONFIRMATION_NO'));
                $this->session->set_userdata('serial',$check->customer_id);
                $this->session->set_userdata('address',$check->cust_add);
                $this->session->set_userdata('phone',$check->phone);
                $this->session->set_userdata('image',$_SESSION['image']);
                $this->session->set_userdata('signature',$_SESSION['signature']);
                $this->session->set_userdata('prog',$check->prog_type);
                $this->session->set_userdata('dept',$check->dept);
                $this->session->set_userdata('password',$_SESSION['password']);
                $this->session->set_userdata('fullname',$check->fullname); //get from student input
                $this->session->set_userdata('bankcode',$check->bankcode); //get from student input
                $this->session->set_userdata('bankname',$check->bankname);
                $this->session->set_userdata('branchcode',$check->branchcode);
                $this->session->set_userdata('conff',$check->confirm_code);
                $this->session->set_userdata('amount',$check->amount);
                $this->session->set_userdata('descr',$check->description);
                $this->session->set_userdata('date',$check->payment_date);

                $_SESSION['err_msg'] = "This Etranzact Confirmation Code was previously been used You...";
                $link = '<a target ="_blank" href='.base_url().'index.php?student/printer/manual>Click here to print your School Fees reciept</a>';
                 $_SESSION['prn_msg'] = $link;
               }
               else if(!$check){
                $_SESSION['err_msg'] = "This Etranzact Confirmation Code was used by Another Student...";

               }
            }else{
               //echo "insering into manual_etranzact";
              $data['customer_id'] =  $this->session->userdata('serial');
              $data['date_reg'] =  date("Y-m-d");
              $data['fullname'] =  $this->session->userdata('fullname');
              $data['receipt_no'] =  $this->session->userdata('receipt');
              $data['confirm_code'] = $this->session->userdata('conff');
              $data['description'] = $this->session->userdata('descr');
              $data['amount'] =    $this->session->userdata('amount');
              $data['phone'] =    $this->session->userdata('phone');
              $data['prog_type'] =      $this->session->userdata('prog');
              $data['dept'] =      $this->session->userdata('dept');
              $data['level'] =      $this->session->userdata('level');
              $data['session'] =      $this->session->userdata('session');
              $data['bankcode'] =  $this->session->userdata('bankcode');
              $data['branchcode'] =  $this->session->userdata('branchcode');
              $data['cust_add'] =     $this->session->userdata('address');
              $data['payment_date'] =   $this->session->userdata('date');
              $data['used_by'] =      $this->session->userdata('reg_no');
              $data['status'] =       "paid";

              if($data['confirm_code'] == 0 || $data['confirm_code'] == '0'){
                $_SESSION['err_msg'] = "Transaction unsuccessful...";
                return false;
                exit;
              }
                
              $this->db->insert('manual_etranzact', $data);
              /*Start Ozioma*/
              $this->load->library('ozioma'); //load the ozioma library  $this->input->post('message')
              $this->ozioma->set_message("Hello ".$this->session->userdata('fullname').", Your fee has been successfully processed for the ".$this->session->userdata('session')." Session. And your login details are: ".$this->session->userdata('reg_no')." & password: ".$this->session->userdata('password')."");//message from textfield
              $this->ozioma->set_recipient($this->session->userdata('phone'));//separate numbers with commas and include zip code in every number
              $this->ozioma->set_sender("Alvan Reg");//sender from database
              $this->ozioma->send();
              /*Emd Ozioma */

              $_SESSION['err_msg'] = "Correct Confirmation Code...";
              $link = '<a target ="_blank" href='.base_url().'index.php?student/printer/manual>Click here to print your School Fees reciept</a>';
              $_SESSION['prn_msg'] = $link;
              }
          }else if(!$manual){
            $_SESSION['err_msg'] = "Sorry: This Etranzact Confirmation Code is invalid...";
          }

        }// end of param m

          //$page_data['page_name']  = 'register5';
          /*$page_data['page_name']  = 'print';
        $page_data['page_title'] = get_phrase('Alvan Ikoku College of Education | Register');
         $this->load->view('backend/printout', $page_data); */
          $page_data['page_name']  = 'register4';
        $page_data['page_title'] = get_phrase('Alvan Ikoku College of Education | Register');
         $this->load->view('backend/register', $page_data);

    }




}


